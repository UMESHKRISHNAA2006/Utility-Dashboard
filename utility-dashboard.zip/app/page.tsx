import { Greeting } from "@/components/greeting"
import { ThemeButton } from "@/components/theme-button"
import { Calculator } from "@/components/calculator"

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="space-y-8">
          <Greeting />
          <div className="flex flex-col items-center justify-center space-y-12 py-8">
            <ThemeButton />
            <Calculator />
          </div>
        </div>
      </div>
    </div>
  )
}
