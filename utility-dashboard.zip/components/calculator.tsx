"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Plus } from "lucide-react"

export function Calculator() {
  const [num1, setNum1] = useState("")
  const [num2, setNum2] = useState("")
  const [result, setResult] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)

  const handleCalculate = () => {
    const sum = Number.parseFloat(num1) + Number.parseFloat(num2)

    if (!isNaN(sum)) {
      setResult(sum)
      setShowResult(false)

      // Trigger animation after a brief delay
      setTimeout(() => {
        setShowResult(true)
      }, 100)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="w-full max-w-md bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 backdrop-blur-sm bg-opacity-80 dark:bg-opacity-80"
    >
      <h2 className="text-xl font-bold text-center mb-6 text-gray-800 dark:text-white">Calculator</h2>

      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="num1" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              First Number
            </label>
            <input
              id="num1"
              type="number"
              value={num1}
              onChange={(e) => setNum1(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              placeholder="Enter a number"
            />
          </div>

          <div>
            <label htmlFor="num2" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Second Number
            </label>
            <input
              id="num2"
              type="number"
              value={num2}
              onChange={(e) => setNum2(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              placeholder="Enter a number"
            />
          </div>
        </div>

        <div className="flex justify-center">
          <Plus className="text-gray-400 my-2" />
        </div>

        <div className="flex justify-center">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleCalculate}
            className="px-6 py-2 bg-blue-500 text-white font-medium rounded-lg shadow hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
          >
            Calculate
          </motion.button>
        </div>

        <div className="mt-6">
          <div className="text-center text-sm text-gray-600 dark:text-gray-400 mb-2">Result</div>
          <AnimatePresence mode="wait">
            {showResult && result !== null && (
              <motion.div
                key={result}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{
                  scale: [0.8, 1.1, 1],
                  opacity: 1,
                }}
                transition={{
                  duration: 0.5,
                  times: [0, 0.6, 1],
                }}
                className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg text-center font-bold text-2xl text-blue-600 dark:text-blue-400 shadow-inner"
              >
                {result}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  )
}
