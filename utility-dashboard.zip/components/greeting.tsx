"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export function Greeting() {
  const [greeting, setGreeting] = useState("")
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const hours = new Date().getHours()
    let greetingText = ""

    if (hours >= 5 && hours < 12) {
      greetingText = "Good Morning"
    } else if (hours >= 12 && hours < 18) {
      greetingText = "Good Afternoon"
    } else {
      greetingText = "Good Evening"
    }

    setGreeting(greetingText)

    // Trigger fade-in animation after a short delay
    const timer = setTimeout(() => {
      setVisible(true)
    }, 300)

    return () => clearTimeout(timer)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: visible ? 1 : 0, y: visible ? 0 : -20 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="text-center py-8"
    >
      <h1 className="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white">
        {greeting}, <span className="text-blue-600 dark:text-blue-400">User</span>
      </h1>
      <p className="mt-2 text-gray-600 dark:text-gray-300">Welcome to your utility dashboard</p>
    </motion.div>
  )
}
