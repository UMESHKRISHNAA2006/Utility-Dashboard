"use client"

import { useState } from "react"
import { motion } from "framer-motion"

export function ThemeButton() {
  const colors = [
    { bg: "bg-blue-500", hover: "hover:bg-blue-600", text: "Blue" },
    { bg: "bg-green-500", hover: "hover:bg-green-600", text: "Green" },
    { bg: "bg-red-500", hover: "hover:bg-red-600", text: "Red" },
    { bg: "bg-purple-500", hover: "hover:bg-purple-600", text: "Purple" },
  ]

  const [currentColorIndex, setCurrentColorIndex] = useState(0)
  const currentColor = colors[currentColorIndex]

  const handleClick = () => {
    setCurrentColorIndex((prevIndex) => (prevIndex + 1) % colors.length)
  }

  return (
    <motion.div className="text-center" initial={{ scale: 0.9 }} animate={{ scale: 1 }} transition={{ duration: 0.5 }}>
      <motion.button
        className={`${currentColor.bg} ${currentColor.hover} text-white font-semibold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
        onClick={handleClick}
        whileTap={{ scale: 0.95 }}
      >
        Change Theme to {colors[(currentColorIndex + 1) % colors.length].text}
      </motion.button>
      <p className="mt-3 text-sm text-gray-600 dark:text-gray-300">Current theme: {currentColor.text}</p>
    </motion.div>
  )
}
