"use client"

import { useState, useEffect } from "react"

type TimeOfDay = "morning" | "afternoon" | "evening" | "night"

export function useTime() {
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>("morning")
  const [currentTime, setCurrentTime] = useState<Date>(new Date())

  useEffect(() => {
    // Update time initially
    updateTimeOfDay()

    // Set up interval to update time every minute
    const intervalId = setInterval(() => {
      setCurrentTime(new Date())
      updateTimeOfDay()
    }, 60000)

    return () => clearInterval(intervalId)
  }, [])

  const updateTimeOfDay = () => {
    const hours = new Date().getHours()

    if (hours >= 5 && hours < 12) {
      setTimeOfDay("morning")
    } else if (hours >= 12 && hours < 18) {
      setTimeOfDay("afternoon")
    } else if (hours >= 18 && hours < 22) {
      setTimeOfDay("evening")
    } else {
      setTimeOfDay("night")
    }
  }

  return { timeOfDay, currentTime }
}
